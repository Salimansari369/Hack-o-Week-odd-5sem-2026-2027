"""
Application factory for CampusCare.

Using the factory pattern (rather than a single global `app` object)
keeps the codebase testable and allows multiple configurations
(development / testing / production) to be instantiated cleanly.
"""

import os
from flask import Flask

from app.config import config_map
from app.extensions import db, cors
from app.utils.errors import register_error_handlers


def create_app(config_name=None):
    if config_name is None:
        config_name = os.getenv("FLASK_ENV", "default")

    app = Flask(__name__)
    app.config.from_object(config_map.get(config_name, config_map["default"]))

    # --- Extensions -------------------------------------------------
    db.init_app(app)
    cors.init_app(app, resources={r"/api/*": {"origins": "*"}})

    # --- Blueprints ---------------------------------------------------
    from app.routes.main import main_bp
    from app.routes.complaints import complaints_bp
    from app.routes.updates import updates_bp
    from app.routes.stats import stats_bp
    from app.routes.meta import meta_bp
    from app.routes.auth import auth_bp

    app.register_blueprint(main_bp)
    app.register_blueprint(complaints_bp)
    app.register_blueprint(updates_bp)
    app.register_blueprint(stats_bp)
    app.register_blueprint(meta_bp)
    app.register_blueprint(auth_bp)

    # --- Centralized error handling -----------------------------------
    register_error_handlers(app)

    # --- Database bootstrap --------------------------------------------
    with app.app_context():
        from app import models  # noqa: F401  (ensures models are registered)
        db.create_all()

    return app
