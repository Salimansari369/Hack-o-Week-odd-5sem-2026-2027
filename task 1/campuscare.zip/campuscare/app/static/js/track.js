/* Track Complaint page */

const trackForm = document.getElementById("track-form");
const trackError = document.getElementById("track-error");
const trackResult = document.getElementById("track-result");

trackForm.addEventListener("submit", async (e) => {
  e.preventDefault();
  trackError.innerHTML = "";
  trackResult.innerHTML = "";

  const raw = document.getElementById("ticket-id").value.trim().replace("#", "");
  const id = parseInt(raw, 10);

  if (!raw || isNaN(id) || id <= 0) {
    trackError.innerHTML = `<div class="alert alert-error">Enter a valid numeric ticket ID.</div>`;
    return;
  }

  trackResult.innerHTML = `<div class="loading-state"><div class="spinner"></div>Looking up ticket #${id}&hellip;</div>`;

  const res = await CampusCareAPI.getComplaint(id);

  if (!res.ok) {
    trackResult.innerHTML = "";
    trackError.innerHTML = `<div class="alert alert-error">${escapeHTML(res.message || "Ticket not found.")}</div>`;
    return;
  }

  window.location.href = `/complaint/${id}`;
});
