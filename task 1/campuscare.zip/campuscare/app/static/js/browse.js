/* Browse Complaints page -- search, filter, sort, paginate */

let currentPage = 1;
let debounceTimer = null;

const searchInput = document.getElementById("search-input");
const statusFilter = document.getElementById("filter-status");
const categoryFilter = document.getElementById("filter-category");
const priorityFilter = document.getElementById("filter-priority");
const sortFilter = document.getElementById("filter-sort");
const listEl = document.getElementById("complaint-list");
const metaEl = document.getElementById("results-meta");
const paginationEl = document.getElementById("pagination");

async function populateCategoryFilter() {
  const res = await CampusCareAPI.getMeta();
  if (!res.ok) return;
  res.data.categories.forEach((c) =>
    categoryFilter.insertAdjacentHTML("beforeend", `<option value="${escapeHTML(c)}">${escapeHTML(c)}</option>`)
  );
}

function readQueryParams() {
  const url = new URLSearchParams(window.location.search);
  if (url.get("search")) searchInput.value = url.get("search");
  if (url.get("status")) statusFilter.value = url.get("status");
  if (url.get("category")) categoryFilter.value = url.get("category");
}

async function loadComplaints() {
  listEl.innerHTML = `<div class="loading-state" style="grid-column:1/-1;"><div class="spinner"></div>Loading complaints&hellip;</div>`;

  const query = {
    search: searchInput.value.trim(),
    status: statusFilter.value,
    category: categoryFilter.value,
    priority: priorityFilter.value,
    sort: sortFilter.value,
    page: currentPage,
    per_page: 9,
  };

  const res = await CampusCareAPI.listComplaints(query);

  if (!res.ok) {
    listEl.innerHTML = `<div class="empty-state" style="grid-column:1/-1;"><div class="icon">⚠️</div><h3>Could not load complaints</h3><p>${escapeHTML(res.message)}</p></div>`;
    metaEl.textContent = "";
    paginationEl.innerHTML = "";
    return;
  }

  const { data, meta } = res;
  metaEl.textContent = `${meta.total_items} result${meta.total_items === 1 ? "" : "s"} found`;

  if (data.length === 0) {
    listEl.innerHTML = `
      <div class="empty-state" style="grid-column:1/-1;">
        <div class="icon">🔍</div>
        <h3>No complaints match your filters</h3>
        <p>Try clearing a filter or searching a different term.</p>
      </div>`;
    paginationEl.innerHTML = "";
    return;
  }

  listEl.innerHTML = data.map(complaintCardHTML).join("");
  renderPagination(meta);
}

function renderPagination(meta) {
  if (meta.total_pages <= 1) { paginationEl.innerHTML = ""; return; }

  let html = "";
  html += `<button ${!meta.has_prev ? "disabled" : ""} data-page="${meta.page - 1}">&larr; Prev</button>`;
  for (let i = 1; i <= meta.total_pages; i++) {
    if (i === 1 || i === meta.total_pages || Math.abs(i - meta.page) <= 1) {
      html += `<button class="${i === meta.page ? "active" : ""}" data-page="${i}">${i}</button>`;
    } else if (Math.abs(i - meta.page) === 2) {
      html += `<span style="padding:0 4px; color:var(--ink-soft);">&hellip;</span>`;
    }
  }
  html += `<button ${!meta.has_next ? "disabled" : ""} data-page="${meta.page + 1}">Next &rarr;</button>`;
  paginationEl.innerHTML = html;

  paginationEl.querySelectorAll("button[data-page]").forEach((btn) => {
    btn.addEventListener("click", () => {
      currentPage = parseInt(btn.dataset.page, 10);
      loadComplaints();
      window.scrollTo({ top: listEl.offsetTop - 100, behavior: "smooth" });
    });
  });
}

function debounceReload() {
  clearTimeout(debounceTimer);
  debounceTimer = setTimeout(() => { currentPage = 1; loadComplaints(); }, 350);
}

[statusFilter, categoryFilter, priorityFilter, sortFilter].forEach((el) =>
  el.addEventListener("change", () => { currentPage = 1; loadComplaints(); })
);
searchInput.addEventListener("input", debounceReload);

document.getElementById("clear-filters").addEventListener("click", () => {
  searchInput.value = "";
  statusFilter.value = "";
  categoryFilter.value = "";
  priorityFilter.value = "";
  sortFilter.value = "newest";
  currentPage = 1;
  loadComplaints();
});

readQueryParams();
populateCategoryFilter().then(loadComplaints);
