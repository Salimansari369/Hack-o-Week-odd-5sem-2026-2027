/* Admin Dashboard -- table view with status actions, edit, delete */

if (!getAdminKey()) {
  window.location.href = "/admin/login";
}

let statusTransitions = {};
let currentPage = 1;
let pendingDeleteId = null;
let pendingUpdateComplaint = null;
let debounceTimer = null;

const searchEl = document.getElementById("admin-search");
const statusFilterEl = document.getElementById("admin-status-filter");
const categoryFilterEl = document.getElementById("admin-category-filter");
const priorityFilterEl = document.getElementById("admin-priority-filter");
const tbody = document.getElementById("admin-table-body");
const paginationEl = document.getElementById("admin-pagination");

document.getElementById("logout-btn").addEventListener("click", () => {
  clearAdminKey();
  window.location.href = "/admin/login";
});

async function init() {
  const metaRes = await CampusCareAPI.getMeta();
  if (metaRes.ok) {
    statusTransitions = metaRes.data.status_transitions;
    metaRes.data.categories.forEach((c) =>
      categoryFilterEl.insertAdjacentHTML("beforeend", `<option value="${escapeHTML(c)}">${escapeHTML(c)}</option>`)
    );
  }
  loadStats();
  loadTable();
}

async function loadStats() {
  const res = await CampusCareAPI.getStats();
  if (!res.ok) return;
  document.getElementById("as-total").textContent = res.data.total_complaints;
  document.getElementById("as-pending").textContent = res.data.pending;
  document.getElementById("as-progress").textContent = res.data.in_progress;
  document.getElementById("as-resolved").textContent = res.data.resolved;
}

async function loadTable() {
  tbody.innerHTML = `<tr><td colspan="8" style="text-align:center; padding:40px;"><div class="spinner"></div>Loading&hellip;</td></tr>`;

  const query = {
    search: searchEl.value.trim(),
    status: statusFilterEl.value,
    category: categoryFilterEl.value,
    priority: priorityFilterEl.value,
    page: currentPage,
    per_page: 10,
  };

  const res = await CampusCareAPI.listComplaints(query);

  if (!res.ok) {
    tbody.innerHTML = `<tr><td colspan="8" style="text-align:center; padding:40px;">Could not load complaints: ${escapeHTML(res.message)}</td></tr>`;
    return;
  }

  if (res.data.length === 0) {
    tbody.innerHTML = `<tr><td colspan="8" style="text-align:center; padding:40px;">No complaints match these filters.</td></tr>`;
    paginationEl.innerHTML = "";
    return;
  }

  tbody.innerHTML = res.data.map(rowHTML).join("");
  attachRowHandlers();
  renderPagination(res.meta);
}

function rowHTML(c) {
  const isTerminal = c.status === "Resolved" || c.status === "Rejected";
  return `
    <tr data-id="${c.id}">
      <td class="mono">#${String(c.id).padStart(4, "0")}</td>
      <td><a href="/complaint/${c.id}" style="font-weight:600; color:var(--ink-navy);">${escapeHTML(c.title)}</a></td>
      <td>${categoryBadge(c.category)}</td>
      <td>${escapeHTML(c.building)} / ${escapeHTML(c.room_number)}</td>
      <td>${priorityBadge(c.priority)}</td>
      <td>${statusBadge(c.status)}</td>
      <td class="text-soft" style="font-size:12px;">${timeAgo(c.created_at)}</td>
      <td>
        <div class="row-actions">
          <button class="btn btn-sm btn-outline" data-action="update" ${isTerminal ? "disabled" : ""}>Update</button>
          <button class="btn btn-sm btn-danger" data-action="delete">Delete</button>
        </div>
      </td>
    </tr>
  `;
}

function attachRowHandlers() {
  tbody.querySelectorAll("tr[data-id]").forEach((row) => {
    const id = parseInt(row.dataset.id, 10);

    row.querySelector('[data-action="delete"]').addEventListener("click", () => {
      pendingDeleteId = id;
      document.getElementById("admin-delete-text").textContent =
        `This permanently removes ticket #${String(id).padStart(4, "0")} and its history.`;
      document.getElementById("admin-delete-modal").classList.remove("hidden");
    });

    const updateBtn = row.querySelector('[data-action="update"]');
    if (updateBtn) {
      updateBtn.addEventListener("click", async () => {
        const res = await CampusCareAPI.getComplaint(id);
        if (!res.ok) { showToast("Could not load complaint.", "error"); return; }
        openUpdateModal(res.data);
      });
    }
  });
}

function openUpdateModal(c) {
  pendingUpdateComplaint = c;
  document.getElementById("update-modal-title").textContent = `Update Ticket #${String(c.id).padStart(4, "0")}`;
  const select = document.getElementById("update-status-select");
  const allowed = statusTransitions[c.status] || [];
  select.innerHTML = allowed.map((s) => `<option value="${escapeHTML(s)}">${escapeHTML(s)}</option>`).join("");
  document.getElementById("update-remark-input").value = "";
  document.getElementById("update-modal-alert").innerHTML = "";
  document.getElementById("admin-update-modal").classList.remove("hidden");
}

document.getElementById("admin-cancel-update").addEventListener("click", () => {
  document.getElementById("admin-update-modal").classList.add("hidden");
});

document.getElementById("admin-confirm-update").addEventListener("click", async () => {
  if (!pendingUpdateComplaint) return;
  const status = document.getElementById("update-status-select").value;
  const remark = document.getElementById("update-remark-input").value.trim();
  const alertBox = document.getElementById("update-modal-alert");

  const res = await CampusCareAPI.createUpdate({
    complaint_id: pendingUpdateComplaint.id,
    status,
    remark,
    updated_by: "Admin Console",
  });

  if (!res.ok) {
    alertBox.innerHTML = `<div class="alert alert-error">${escapeHTML(res.message)}</div>`;
    return;
  }

  document.getElementById("admin-update-modal").classList.add("hidden");
  showToast(res.message, "success");
  loadStats();
  loadTable();
});

document.getElementById("admin-cancel-delete").addEventListener("click", () => {
  document.getElementById("admin-delete-modal").classList.add("hidden");
});

document.getElementById("admin-confirm-delete").addEventListener("click", async () => {
  if (pendingDeleteId === null) return;
  const res = await CampusCareAPI.deleteComplaint(pendingDeleteId);
  document.getElementById("admin-delete-modal").classList.add("hidden");
  if (!res.ok) { showToast(res.message || "Delete failed.", "error"); return; }
  showToast("Complaint deleted.", "success");
  pendingDeleteId = null;
  loadStats();
  loadTable();
});

function renderPagination(meta) {
  if (!meta || meta.total_pages <= 1) { paginationEl.innerHTML = ""; return; }
  let html = `<button ${!meta.has_prev ? "disabled" : ""} data-page="${meta.page - 1}">&larr; Prev</button>`;
  for (let i = 1; i <= meta.total_pages; i++) {
    if (i === 1 || i === meta.total_pages || Math.abs(i - meta.page) <= 1) {
      html += `<button class="${i === meta.page ? "active" : ""}" data-page="${i}">${i}</button>`;
    } else if (Math.abs(i - meta.page) === 2) {
      html += `<span style="padding:0 4px;">&hellip;</span>`;
    }
  }
  html += `<button ${!meta.has_next ? "disabled" : ""} data-page="${meta.page + 1}">Next &rarr;</button>`;
  paginationEl.innerHTML = html;
  paginationEl.querySelectorAll("button[data-page]").forEach((btn) => {
    btn.addEventListener("click", () => {
      currentPage = parseInt(btn.dataset.page, 10);
      loadTable();
    });
  });
}

function debounceReload() {
  clearTimeout(debounceTimer);
  debounceTimer = setTimeout(() => { currentPage = 1; loadTable(); }, 350);
}

[statusFilterEl, categoryFilterEl, priorityFilterEl].forEach((el) =>
  el.addEventListener("change", () => { currentPage = 1; loadTable(); })
);
searchEl.addEventListener("input", debounceReload);

init();
