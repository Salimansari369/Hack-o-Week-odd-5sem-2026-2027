/* Admin Login page */

const loginForm = document.getElementById("login-form");
const loginAlert = document.getElementById("login-alert");
const loginBtn = document.getElementById("login-btn");

if (getAdminKey()) {
  window.location.href = "/admin/dashboard";
}

loginForm.addEventListener("submit", async (e) => {
  e.preventDefault();
  loginAlert.innerHTML = "";
  const key = document.getElementById("admin-key").value.trim();

  if (!key) {
    loginAlert.innerHTML = `<div class="alert alert-error">Enter an admin key.</div>`;
    return;
  }

  loginBtn.disabled = true;
  loginBtn.textContent = "Verifying…";

  const res = await CampusCareAPI.verifyAdminKey(key);

  loginBtn.disabled = false;
  loginBtn.textContent = "Sign In";

  if (!res.ok) {
    loginAlert.innerHTML = `<div class="alert alert-error">Invalid admin key. Please try again.</div>`;
    return;
  }

  setAdminKey(key);
  window.location.href = "/admin/dashboard";
});
