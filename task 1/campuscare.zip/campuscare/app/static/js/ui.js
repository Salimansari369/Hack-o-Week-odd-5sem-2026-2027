/* =====================================================================
   CampusCare -- Shared UI helpers
   Mobile nav toggle, badge/tag rendering, date formatting, escaping.
   ===================================================================== */

document.addEventListener("DOMContentLoaded", () => {
  const toggle = document.querySelector(".nav-toggle");
  const links = document.querySelector(".nav-links");
  if (toggle && links) {
    toggle.addEventListener("click", () => links.classList.toggle("open"));
  }

  // Highlight active nav link
  const path = window.location.pathname;
  document.querySelectorAll(".nav-links a[data-path]").forEach((a) => {
    if (a.dataset.path === path) a.classList.add("active");
  });

  // Reflect admin session state in nav, if the marker element exists
  const adminNavLink = document.getElementById("nav-admin-link");
  if (adminNavLink) {
    const key = getAdminKey();
    if (key) {
      adminNavLink.textContent = "Admin Dashboard";
      adminNavLink.setAttribute("href", "/admin/dashboard");
    }
  }
});

function escapeHTML(str) {
  if (str === null || str === undefined) return "";
  return String(str)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#039;");
}

function timeAgo(isoString) {
  if (!isoString) return "";
  const date = new Date(isoString);
  const seconds = Math.floor((new Date() - date) / 1000);

  const intervals = [
    ["year", 31536000], ["month", 2592000], ["week", 604800],
    ["day", 86400], ["hour", 3600], ["minute", 60],
  ];
  for (const [label, secs] of intervals) {
    const count = Math.floor(seconds / secs);
    if (count >= 1) return `${count} ${label}${count > 1 ? "s" : ""} ago`;
  }
  return "just now";
}

function formatDateTime(isoString) {
  if (!isoString) return "";
  const date = new Date(isoString);
  return date.toLocaleString("en-IN", {
    day: "2-digit", month: "short", year: "numeric",
    hour: "2-digit", minute: "2-digit",
  });
}

function statusClass(status) {
  return "status-" + status.toLowerCase().replace(/\s+/g, "-");
}

function priorityClass(priority) {
  return "tag-priority-" + priority.toLowerCase();
}

function statusBadge(status) {
  return `<span class="tag status-badge ${statusClass(status)}">${escapeHTML(status)}</span>`;
}

function priorityBadge(priority) {
  return `<span class="tag ${priorityClass(priority)}">${escapeHTML(priority)} priority</span>`;
}

function categoryBadge(category) {
  return `<span class="tag tag-cat">${escapeHTML(category)}</span>`;
}

/** Renders a single complaint as a ticket-style card (used on home/browse). */
function complaintCardHTML(c) {
  return `
    <div class="card">
      <a class="card-link" href="/complaint/${c.id}">
        <div class="card-body">
          <div class="card-top-row">
            <span class="card-id mono">TICKET #${String(c.id).padStart(4, "0")}</span>
            ${statusBadge(c.status)}
          </div>
          <h3>${escapeHTML(c.title)}</h3>
          <p class="desc">${escapeHTML(c.description)}</p>
          <div class="card-tags">
            ${categoryBadge(c.category)}
            ${priorityBadge(c.priority)}
          </div>
          <div class="card-foot">
            <span>${escapeHTML(c.building)} &middot; Room ${escapeHTML(c.room_number)}</span>
            <span>${timeAgo(c.created_at)}</span>
          </div>
        </div>
      </a>
    </div>
  `;
}

function showToast(message, type = "info") {
  let container = document.getElementById("toast-container");
  if (!container) {
    container = document.createElement("div");
    container.id = "toast-container";
    container.style.cssText = "position:fixed;bottom:20px;right:20px;z-index:2000;display:flex;flex-direction:column;gap:10px;max-width:340px;";
    document.body.appendChild(container);
  }
  const toast = document.createElement("div");
  const bg = type === "error" ? "#C1442D" : type === "success" ? "#2F6D4F" : "#14213D";
  toast.style.cssText = `background:${bg};color:#fff;padding:13px 16px;border-radius:8px;font-size:13.5px;font-weight:600;box-shadow:0 8px 24px rgba(0,0,0,0.2);`;
  toast.textContent = message;
  container.appendChild(toast);
  setTimeout(() => {
    toast.style.transition = "opacity .3s ease";
    toast.style.opacity = "0";
    setTimeout(() => toast.remove(), 300);
  }, 3800);
}
