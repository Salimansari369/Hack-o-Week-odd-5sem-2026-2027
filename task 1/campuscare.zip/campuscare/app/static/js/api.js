/* =====================================================================
   CampusCare -- API Client
   A thin wrapper around fetch() that talks to the Flask REST API.
   Every page includes this file before its own page script.
   ===================================================================== */

const API_BASE = "/api";

function getAdminKey() {
  return localStorage.getItem("campuscare_admin_key") || "";
}

function setAdminKey(key) {
  localStorage.setItem("campuscare_admin_key", key);
}

function clearAdminKey() {
  localStorage.removeItem("campuscare_admin_key");
}

/**
 * Core request helper. Returns the parsed JSON body regardless of
 * status code, and attaches the HTTP status so callers can branch on
 * success/failure without a second round trip.
 */
async function apiRequest(path, { method = "GET", body = null, auth = false, query = null } = {}) {
  let url = `${API_BASE}${path}`;

  if (query) {
    const params = new URLSearchParams();
    Object.entries(query).forEach(([k, v]) => {
      if (v !== undefined && v !== null && v !== "") params.append(k, v);
    });
    const qs = params.toString();
    if (qs) url += `?${qs}`;
  }

  const headers = { "Content-Type": "application/json" };
  if (auth) headers["X-Admin-Key"] = getAdminKey();

  const options = { method, headers };
  if (body !== null) options.body = JSON.stringify(body);

  let response, data;
  try {
    response = await fetch(url, options);
    data = await response.json();
  } catch (err) {
    return {
      ok: false,
      status: 0,
      message: "Could not reach the CampusCare server. Check your connection and try again.",
      errors: [],
    };
  }

  return {
    ok: response.ok,
    status: response.status,
    message: data.message || "",
    errors: data.errors || [],
    data: data.data,
    meta: data.meta,
  };
}

const CampusCareAPI = {
  // ---- Meta ----
  getMeta: () => apiRequest("/meta"),

  // ---- Complaints ----
  listComplaints: (query) => apiRequest("/complaints", { query }),
  getComplaint: (id) => apiRequest(`/complaints/${id}`),
  createComplaint: (payload) => apiRequest("/complaints", { method: "POST", body: payload }),
  patchComplaint: (id, payload) => apiRequest(`/complaints/${id}`, { method: "PATCH", body: payload, auth: true }),
  deleteComplaint: (id) => apiRequest(`/complaints/${id}`, { method: "DELETE", auth: true }),
  getComplaintUpdates: (id) => apiRequest(`/complaints/${id}/updates`),

  // ---- Updates (status changes) ----
  createUpdate: (payload) => apiRequest("/updates", { method: "POST", body: payload, auth: true }),

  // ---- Stats ----
  getStats: () => apiRequest("/stats"),

  // ---- Admin auth ----
  verifyAdminKey: (admin_key) => apiRequest("/admin/verify", { method: "POST", body: { admin_key } }),
};
