/* Report Complaint page */

const form = document.getElementById("report-form");
const alertBox = document.getElementById("form-alert");
const submitBtn = document.getElementById("submit-btn");

const FIELD_IDS = ["title", "description", "category", "priority", "building", "room_number", "reported_by", "email", "phone"];

async function populateDropdowns() {
  const res = await CampusCareAPI.getMeta();
  if (!res.ok) {
    alertBox.innerHTML = `<div class="alert alert-error">Could not load form options. Refresh the page to try again.</div>`;
    return;
  }
  const { categories, buildings, priorities } = res.data;

  const catSelect = document.getElementById("category");
  categories.forEach((c) => catSelect.insertAdjacentHTML("beforeend", `<option value="${escapeHTML(c)}">${escapeHTML(c)}</option>`));

  const buildSelect = document.getElementById("building");
  buildings.forEach((b) => buildSelect.insertAdjacentHTML("beforeend", `<option value="${escapeHTML(b)}">${escapeHTML(b)}</option>`));

  const prioSelect = document.getElementById("priority");
  priorities.forEach((p) => prioSelect.insertAdjacentHTML("beforeend", `<option value="${escapeHTML(p)}">${escapeHTML(p)}</option>`));
  prioSelect.value = "Medium";
}

function clearFieldErrors() {
  FIELD_IDS.forEach((id) => {
    const wrap = document.getElementById(`f-${id}`);
    wrap.classList.remove("error");
    wrap.querySelector(".field-error-msg").classList.add("hidden");
  });
  alertBox.innerHTML = "";
}

function showFieldError(fieldName, message) {
  const wrap = document.getElementById(`f-${fieldName}`);
  if (!wrap) return false;
  wrap.classList.add("error");
  const msgEl = wrap.querySelector(".field-error-msg");
  msgEl.textContent = message;
  msgEl.classList.remove("hidden");
  return true;
}

/** Maps a backend error string like "'title' is required..." to its field id. */
function applyServerErrors(errors) {
  let matchedAny = false;
  errors.forEach((err) => {
    const match = err.match(/'([a-z_]+)'/);
    if (match && FIELD_IDS.includes(match[1])) {
      showFieldError(match[1], err);
      matchedAny = true;
    }
  });
  if (!matchedAny) {
    alertBox.innerHTML = `<div class="alert alert-error">${escapeHTML(errors.join(" "))}</div>`;
  }
}

form.addEventListener("submit", async (e) => {
  e.preventDefault();
  clearFieldErrors();

  const payload = {};
  FIELD_IDS.forEach((id) => { payload[id] = document.getElementById(id).value.trim(); });

  submitBtn.disabled = true;
  submitBtn.textContent = "Submitting…";

  const res = await CampusCareAPI.createComplaint(payload);

  submitBtn.disabled = false;
  submitBtn.textContent = "Submit Complaint";

  if (!res.ok) {
    if (res.status === 409) {
      alertBox.innerHTML = `<div class="alert alert-error">⚠ ${escapeHTML(res.message)}</div>`;
    } else if (res.errors && res.errors.length) {
      applyServerErrors(res.errors);
    } else {
      alertBox.innerHTML = `<div class="alert alert-error">${escapeHTML(res.message || "Something went wrong.")}</div>`;
    }
    alertBox.scrollIntoView({ behavior: "smooth", block: "center" });
    return;
  }

  document.getElementById("modal-ticket-id").textContent = "#" + String(res.data.id).padStart(4, "0");
  document.getElementById("success-modal").classList.remove("hidden");
  form.reset();
  document.getElementById("priority").value = "Medium";
});

populateDropdowns();
