/* Complaint Detail page -- public view + admin actions panel */

let statusTransitions = {};
let currentComplaint = null;

async function loadDetail() {
  const container = document.getElementById("detail-container");

  const [metaRes, res] = await Promise.all([
    CampusCareAPI.getMeta(),
    CampusCareAPI.getComplaint(COMPLAINT_ID),
  ]);

  if (metaRes.ok) statusTransitions = metaRes.data.status_transitions;

  if (!res.ok) {
    container.innerHTML = `
      <div class="empty-state">
        <div class="icon">🔍</div>
        <h3>Ticket not found</h3>
        <p>${escapeHTML(res.message || "No complaint exists with this ID.")}</p>
        <a href="/track" class="btn btn-outline mt-16">Try another ticket ID</a>
      </div>`;
    return;
  }

  currentComplaint = res.data;
  render(currentComplaint);
}

function render(c) {
  const isAdmin = !!getAdminKey();
  const container = document.getElementById("detail-container");

  const allowedNext = statusTransitions[c.status] || [];

  container.innerHTML = `
    <div class="flex-between mb-16" style="flex-wrap:wrap; gap:12px;">
      <div>
        <span class="card-id mono">TICKET #${String(c.id).padStart(4, "0")}</span>
        <h1 style="font-size:26px; margin-top:6px;">${escapeHTML(c.title)}</h1>
      </div>
      ${statusBadge(c.status)}
    </div>

    <div class="detail-grid">
      <div>
        <div class="form-card mb-16">
          <h3 style="font-size:15px; margin-bottom:12px;">Description</h3>
          <p class="text-soft" style="font-size:14.5px; line-height:1.7;">${escapeHTML(c.description)}</p>
          <div class="card-tags mt-16">
            ${categoryBadge(c.category)}
            ${priorityBadge(c.priority)}
          </div>
        </div>

        <div class="form-card">
          <h3 style="font-size:15px; margin-bottom:16px;">Status History</h3>
          <div class="timeline" id="timeline"></div>
        </div>
      </div>

      <div>
        <div class="form-card mb-16">
          <h3 style="font-size:15px; margin-bottom:12px;">Ticket Details</h3>
          <div class="info-row"><span class="k">Building</span><span class="v">${escapeHTML(c.building)}</span></div>
          <div class="info-row"><span class="k">Room / Location</span><span class="v">${escapeHTML(c.room_number)}</span></div>
          <div class="info-row"><span class="k">Reported by</span><span class="v">${escapeHTML(c.reported_by)}</span></div>
          <div class="info-row"><span class="k">Email</span><span class="v">${escapeHTML(c.email)}</span></div>
          <div class="info-row"><span class="k">Phone</span><span class="v">${escapeHTML(c.phone)}</span></div>
          <div class="info-row"><span class="k">Filed</span><span class="v">${formatDateTime(c.created_at)}</span></div>
          <div class="info-row"><span class="k">Last updated</span><span class="v">${formatDateTime(c.updated_at)}</span></div>
        </div>

        <div class="form-card" id="admin-panel">
          ${isAdmin ? renderAdminPanel(c, allowedNext) : `
            <h3 style="font-size:15px; margin-bottom:10px;">Staff actions</h3>
            <p class="text-soft" style="font-size:13.5px;">Sign in as an administrator to update status, add remarks, or manage this ticket.</p>
            <a href="/admin/login" class="btn btn-outline btn-block mt-16">Admin Login</a>
          `}
        </div>
      </div>
    </div>
  `;

  renderTimeline(c.updates || []);
  if (isAdmin) attachAdminHandlers(c);
}

function renderTimeline(updates) {
  const el = document.getElementById("timeline");
  if (!updates.length) {
    el.innerHTML = `<p class="text-soft" style="font-size:13.5px;">No history yet.</p>`;
    return;
  }
  el.innerHTML = updates.map((u) => `
    <div class="timeline-item ${statusClass(u.status)}">
      <div class="t-head">
        ${statusBadge(u.status)}
        <span class="t-time mono">${formatDateTime(u.updated_at)}</span>
      </div>
      ${u.remark ? `<div class="t-remark">${escapeHTML(u.remark)}</div>` : ""}
      <div class="t-by">by ${escapeHTML(u.updated_by)}</div>
    </div>
  `).join("");
}

function renderAdminPanel(c, allowedNext) {
  let actionButtons = "";
  if (c.status === "Resolved" || c.status === "Rejected") {
    actionButtons = `<p class="text-soft" style="font-size:13px;">This ticket is in a terminal state and cannot be changed further.</p>`;
  } else {
    actionButtons = allowedNext.map((s) => {
      const cls = s === "Resolved" ? "btn-navy" : s === "Rejected" ? "btn-outline" : "btn-amber";
      return `<button class="btn ${cls} btn-sm" data-status="${escapeHTML(s)}">Mark ${escapeHTML(s)}</button>`;
    }).join("");
  }

  return `
    <h3 style="font-size:15px; margin-bottom:12px;">Staff actions</h3>
    <div class="field">
      <label for="remark-input">Remark (optional)</label>
      <textarea id="remark-input" placeholder="e.g. Technician assigned, visiting tomorrow" style="min-height:70px;"></textarea>
    </div>
    <div class="flex gap-8" style="flex-wrap:wrap;" id="status-actions">${actionButtons}</div>
    <div id="admin-action-alert" class="mt-16"></div>
    <hr style="border:none; border-top:1px dashed var(--line); margin:18px 0;">
    <button class="btn btn-outline btn-block" id="edit-toggle-btn" ${c.status === "Resolved" || c.status === "Rejected" ? "disabled" : ""}>Edit Details</button>
    <button class="btn btn-danger btn-block mt-8" id="delete-btn">Delete Ticket</button>
  `;
}

function attachAdminHandlers(c) {
  document.querySelectorAll("#status-actions button[data-status]").forEach((btn) => {
    btn.addEventListener("click", async () => {
      const status = btn.dataset.status;
      const remark = document.getElementById("remark-input").value.trim();
      const alertBox = document.getElementById("admin-action-alert");
      btn.disabled = true;
      const res = await CampusCareAPI.createUpdate({
        complaint_id: c.id,
        status,
        remark,
        updated_by: "Admin Console",
      });
      btn.disabled = false;

      if (!res.ok) {
        alertBox.innerHTML = `<div class="alert alert-error">${escapeHTML(res.message)}</div>`;
        return;
      }
      showToast(res.message, "success");
      loadDetail();
    });
  });

  const deleteBtn = document.getElementById("delete-btn");
  if (deleteBtn) {
    deleteBtn.addEventListener("click", () => {
      document.getElementById("delete-modal").classList.remove("hidden");
    });
  }

  const editBtn = document.getElementById("edit-toggle-btn");
  if (editBtn) {
    editBtn.addEventListener("click", () => openEditPrompt(c));
  }
}

function openEditPrompt(c) {
  const newPriority = prompt(`Update priority for ticket #${c.id} (Low / Medium / High):`, c.priority);
  if (!newPriority) return;
  CampusCareAPI.patchComplaint(c.id, { priority: newPriority.trim() }).then((res) => {
    if (!res.ok) {
      showToast(res.message || (res.errors && res.errors[0]) || "Update failed.", "error");
      return;
    }
    showToast("Complaint updated.", "success");
    loadDetail();
  });
}

document.getElementById("cancel-delete")?.addEventListener("click", () => {
  document.getElementById("delete-modal").classList.add("hidden");
});

document.getElementById("confirm-delete")?.addEventListener("click", async () => {
  const res = await CampusCareAPI.deleteComplaint(COMPLAINT_ID);
  document.getElementById("delete-modal").classList.add("hidden");
  if (!res.ok) {
    showToast(res.message || "Could not delete complaint.", "error");
    return;
  }
  showToast("Complaint deleted.", "success");
  setTimeout(() => { window.location.href = "/browse"; }, 700);
});

loadDetail();
