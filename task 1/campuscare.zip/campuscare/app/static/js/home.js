/* Homepage -- live stats + recent complaints */

async function loadHomeStats() {
  const res = await CampusCareAPI.getStats();
  if (!res.ok) return;
  const s = res.data;

  document.getElementById("hm-total").textContent = s.total_complaints;
  document.getElementById("hm-pending").textContent = s.pending;
  document.getElementById("hm-progress").textContent = s.in_progress;
  document.getElementById("hm-resolved").textContent = s.resolved;

  document.getElementById("s-total").textContent = s.total_complaints;
  document.getElementById("s-pending").textContent = s.pending;
  document.getElementById("s-progress").textContent = s.in_progress;
  document.getElementById("s-resolved").textContent = s.resolved;

  renderRecent(s.recent_complaints);
}

function renderRecent(complaints) {
  const container = document.getElementById("recent-complaints");
  if (!complaints || complaints.length === 0) {
    container.innerHTML = `
      <div class="empty-state" style="grid-column:1/-1;">
        <div class="icon">🗂️</div>
        <h3>No complaints yet</h3>
        <p>Be the first to report a campus issue.</p>
      </div>`;
    return;
  }
  container.innerHTML = complaints.map(complaintCardHTML).join("");
}

loadHomeStats();
