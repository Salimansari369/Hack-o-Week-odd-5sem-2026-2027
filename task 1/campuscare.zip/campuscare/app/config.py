"""
Application configuration classes.

CampusCare supports multiple environments (development, testing,
production) selected via the FLASK_ENV environment variable.
"""

import os
from datetime import timedelta

basedir = os.path.abspath(os.path.dirname(os.path.dirname(__file__)))


class BaseConfig:
    """Common configuration shared across all environments."""

    SECRET_KEY = os.getenv("SECRET_KEY", "change-this-secret-key-in-production")
    ADMIN_KEY = os.getenv("ADMIN_KEY", "admin123")

    SQLALCHEMY_TRACK_MODIFICATIONS = False
    JSON_SORT_KEYS = False

    # Pagination defaults for GET /api/complaints
    DEFAULT_PAGE_SIZE = 10
    MAX_PAGE_SIZE = 100

    # Application-level constants
    APP_NAME = "CampusCare"


class DevelopmentConfig(BaseConfig):
    DEBUG = True
    SQLALCHEMY_DATABASE_URI = os.getenv(
        "DATABASE_URI", f"sqlite:///{os.path.join(basedir, 'campuscare.db')}"
    )


class TestingConfig(BaseConfig):
    DEBUG = True
    TESTING = True
    SQLALCHEMY_DATABASE_URI = "sqlite:///:memory:"


class ProductionConfig(BaseConfig):
    DEBUG = False
    SQLALCHEMY_DATABASE_URI = os.getenv(
        "DATABASE_URI", f"sqlite:///{os.path.join(basedir, 'campuscare.db')}"
    )


config_map = {
    "development": DevelopmentConfig,
    "testing": TestingConfig,
    "production": ProductionConfig,
    "default": DevelopmentConfig,
}
