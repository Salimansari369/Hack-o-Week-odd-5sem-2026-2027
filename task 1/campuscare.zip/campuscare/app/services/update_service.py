"""
Business logic for status updates on complaints.

This is where the complaint lifecycle (Pending -> In Progress ->
Resolved, with Rejected as an alternate terminal state) is enforced.
"""

from datetime import datetime

from app.extensions import db
from app.models.update import Update
from app.services.complaint_service import get_complaint_or_404
from app.utils.constants import STATUS_TRANSITIONS
from app.utils.errors import ConflictError


def add_status_update(data):
    complaint_id = int(data["complaint_id"])
    new_status = data["status"].strip()
    updated_by = data["updated_by"].strip()
    remark = str(data.get("remark", "")).strip() or None

    complaint = get_complaint_or_404(complaint_id)
    current_status = complaint.status

    if current_status == new_status:
        raise ConflictError(
            f"Complaint is already in '{current_status}' status. "
            f"Cannot re-apply the same status."
        )

    allowed_next = STATUS_TRANSITIONS.get(current_status, [])
    if new_status not in allowed_next:
        if not allowed_next:
            raise ConflictError(
                f"Complaint is already in a terminal state ('{current_status}') "
                f"and its status cannot be changed further."
            )
        raise ConflictError(
            f"Invalid status transition: '{current_status}' -> '{new_status}'. "
            f"Allowed next status(es) from '{current_status}': {', '.join(allowed_next)}."
        )

    complaint.status = new_status
    complaint.updated_at = datetime.utcnow()

    update = Update(
        complaint_id=complaint.id,
        updated_by=updated_by,
        remark=remark,
        status=new_status,
    )
    db.session.add(update)
    db.session.commit()

    return update, complaint


def get_updates_for_complaint(complaint_id):
    complaint = get_complaint_or_404(complaint_id)
    return complaint.updates
