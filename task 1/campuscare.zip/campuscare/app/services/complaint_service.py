"""
Business logic for complaints.

Routes stay thin -- they parse the request, call into this service,
and translate the result into an HTTP response. All business rules
(duplicate detection, terminal-state protection, filtering, search,
pagination) live here so they are easy to test and reason about.
"""

from datetime import datetime

from sqlalchemy import or_

from app.extensions import db
from app.models.complaint import Complaint
from app.models.update import Update
from app.utils.constants import TERMINAL_STATUSES
from app.utils.errors import NotFoundError, ConflictError, ValidationError


def _find_potential_duplicate(category, building, room_number, title):
    """
    A complaint is treated as a likely duplicate if there is already an
    OPEN (non-terminal) complaint for the same category + building +
    room, with a very similar title.
    """
    candidates = Complaint.query.filter(
        Complaint.category == category,
        Complaint.building == building,
        Complaint.room_number.ilike(room_number.strip()),
        ~Complaint.status.in_(TERMINAL_STATUSES),
    ).all()

    normalized_title = title.strip().lower()
    for c in candidates:
        if c.title.strip().lower() == normalized_title:
            return c
    return None


def create_complaint(data):
    title = data["title"].strip()
    category = data["category"].strip()
    building = data["building"].strip()
    room_number = data["room_number"].strip()

    duplicate = _find_potential_duplicate(category, building, room_number, title)
    if duplicate:
        raise ConflictError(
            "An open complaint with the same title, category, building and room "
            "already exists. Please track the existing complaint instead of "
            "submitting a duplicate.",
            payload={"existing_complaint_id": duplicate.id, "existing_status": duplicate.status},
        )

    complaint = Complaint(
        title=title,
        description=data["description"].strip(),
        category=category,
        building=building,
        room_number=room_number,
        priority=data["priority"].strip(),
        status="Pending",
        reported_by=data["reported_by"].strip(),
        email=data["email"].strip(),
        phone=data["phone"].strip(),
    )
    db.session.add(complaint)
    db.session.commit()

    # Seed the audit trail with the initial "Pending" entry.
    initial_update = Update(
        complaint_id=complaint.id,
        updated_by=complaint.reported_by,
        remark="Complaint reported by student.",
        status="Pending",
    )
    db.session.add(initial_update)
    db.session.commit()

    return complaint


def get_complaint_or_404(complaint_id):
    complaint = Complaint.query.get(complaint_id)
    if not complaint:
        raise NotFoundError(f"No complaint found with id {complaint_id}.")
    return complaint


def list_complaints(args):
    """
    Supports filtering, free-text search and pagination via query
    string parameters:

    status, category, priority, building, search, page, per_page, sort
    """
    query = Complaint.query

    status = args.get("status")
    if status:
        query = query.filter(Complaint.status == status)

    category = args.get("category")
    if category:
        query = query.filter(Complaint.category == category)

    priority = args.get("priority")
    if priority:
        query = query.filter(Complaint.priority == priority)

    building = args.get("building")
    if building:
        query = query.filter(Complaint.building == building)

    search = args.get("search")
    if search:
        like = f"%{search.strip()}%"
        query = query.filter(
            or_(
                Complaint.title.ilike(like),
                Complaint.description.ilike(like),
                Complaint.category.ilike(like),
                Complaint.building.ilike(like),
                Complaint.room_number.ilike(like),
            )
        )

    sort = args.get("sort", "newest")
    if sort == "oldest":
        query = query.order_by(Complaint.created_at.asc())
    elif sort == "priority":
        # High > Medium > Low
        priority_order = db.case(
            (Complaint.priority == "High", 0),
            (Complaint.priority == "Medium", 1),
            (Complaint.priority == "Low", 2),
            else_=3,
        )
        query = query.order_by(priority_order, Complaint.created_at.desc())
    else:
        query = query.order_by(Complaint.created_at.desc())

    try:
        page = max(int(args.get("page", 1)), 1)
    except ValueError:
        page = 1
    try:
        per_page = int(args.get("per_page", 10))
    except ValueError:
        per_page = 10
    per_page = max(1, min(per_page, 100))

    pagination = query.paginate(page=page, per_page=per_page, error_out=False)

    meta = {
        "page": pagination.page,
        "per_page": pagination.per_page,
        "total_items": pagination.total,
        "total_pages": pagination.pages,
        "has_next": pagination.has_next,
        "has_prev": pagination.has_prev,
    }
    return pagination.items, meta


def update_complaint(complaint_id, data):
    """
    Generic field-level update (used by admins to correct details such
    as priority, building, room number, etc). Status transitions are
    handled separately via the Updates service, since they must be
    logged in the audit trail.
    """
    complaint = get_complaint_or_404(complaint_id)

    if complaint.status == "Resolved":
        raise ConflictError("Resolved complaints cannot be edited.")

    editable_fields = [
        "title", "description", "category", "building",
        "room_number", "priority", "reported_by", "email", "phone",
    ]

    # If caller is attempting a status change through this endpoint,
    # redirect them to the proper workflow so every transition is logged.
    if "status" in data and data["status"] != complaint.status:
        raise ValidationError(
            "Status changes must go through POST /api/updates so that "
            "the change is recorded in the complaint's audit trail."
        )

    for field in editable_fields:
        if field in data and data[field] is not None:
            setattr(complaint, field, str(data[field]).strip())

    complaint.updated_at = datetime.utcnow()
    db.session.commit()
    return complaint


def delete_complaint(complaint_id):
    complaint = get_complaint_or_404(complaint_id)
    db.session.delete(complaint)
    db.session.commit()
    return True
