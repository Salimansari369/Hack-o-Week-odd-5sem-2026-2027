"""
Aggregate statistics used by the homepage and admin dashboard.
"""

from sqlalchemy import func
from app.extensions import db
from app.models.complaint import Complaint


def get_dashboard_stats():
    total = Complaint.query.count()

    status_counts_raw = (
        db.session.query(Complaint.status, func.count(Complaint.id))
        .group_by(Complaint.status)
        .all()
    )
    status_counts = {status: count for status, count in status_counts_raw}

    category_counts_raw = (
        db.session.query(Complaint.category, func.count(Complaint.id))
        .group_by(Complaint.category)
        .all()
    )
    category_counts = {category: count for category, count in category_counts_raw}

    priority_counts_raw = (
        db.session.query(Complaint.priority, func.count(Complaint.id))
        .group_by(Complaint.priority)
        .all()
    )
    priority_counts = {priority: count for priority, count in priority_counts_raw}

    building_counts_raw = (
        db.session.query(Complaint.building, func.count(Complaint.id))
        .group_by(Complaint.building)
        .order_by(func.count(Complaint.id).desc())
        .limit(5)
        .all()
    )
    top_buildings = [{"building": b, "count": c} for b, c in building_counts_raw]

    recent = (
        Complaint.query.order_by(Complaint.created_at.desc()).limit(5).all()
    )

    resolved = status_counts.get("Resolved", 0)
    resolution_rate = round((resolved / total) * 100, 1) if total else 0.0

    return {
        "total_complaints": total,
        "pending": status_counts.get("Pending", 0),
        "in_progress": status_counts.get("In Progress", 0),
        "resolved": resolved,
        "rejected": status_counts.get("Rejected", 0),
        "resolution_rate_percent": resolution_rate,
        "category_breakdown": category_counts,
        "priority_breakdown": priority_counts,
        "top_buildings": top_buildings,
        "recent_complaints": [c.to_dict() for c in recent],
    }
