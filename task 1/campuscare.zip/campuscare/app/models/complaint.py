"""
Complaint model.

Represents a single maintenance/complaint ticket raised by a student.
"""

from datetime import datetime
from app.extensions import db


class Complaint(db.Model):
    __tablename__ = "complaints"

    id = db.Column(db.Integer, primary_key=True)

    title = db.Column(db.String(150), nullable=False)
    description = db.Column(db.Text, nullable=False)

    category = db.Column(db.String(50), nullable=False, index=True)
    building = db.Column(db.String(100), nullable=False, index=True)
    room_number = db.Column(db.String(20), nullable=False)

    priority = db.Column(db.String(20), nullable=False, default="Medium")
    status = db.Column(db.String(20), nullable=False, default="Pending", index=True)

    reported_by = db.Column(db.String(100), nullable=False)
    email = db.Column(db.String(120), nullable=False)
    phone = db.Column(db.String(20), nullable=False)

    created_at = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)
    updated_at = db.Column(
        db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow, nullable=False
    )

    updates = db.relationship(
        "Update",
        backref="complaint",
        cascade="all, delete-orphan",
        order_by="desc(Update.updated_at)",
    )

    def to_dict(self, include_updates=False):
        data = {
            "id": self.id,
            "title": self.title,
            "description": self.description,
            "category": self.category,
            "building": self.building,
            "room_number": self.room_number,
            "priority": self.priority,
            "status": self.status,
            "reported_by": self.reported_by,
            "email": self.email,
            "phone": self.phone,
            "created_at": self.created_at.isoformat() + "Z" if self.created_at else None,
            "updated_at": self.updated_at.isoformat() + "Z" if self.updated_at else None,
        }
        if include_updates:
            data["updates"] = [u.to_dict() for u in self.updates]
        return data

    def __repr__(self):
        return f"<Complaint {self.id} | {self.title} | {self.status}>"
