"""
Model package. Import models here so that db.create_all() (invoked in
the application factory) can discover every table.
"""

from app.models.complaint import Complaint
from app.models.update import Update

__all__ = ["Complaint", "Update"]
