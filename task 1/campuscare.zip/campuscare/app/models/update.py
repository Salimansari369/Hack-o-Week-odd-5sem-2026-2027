"""
Update model.

Every status change / remark applied to a complaint is stored as an
immutable Update row, giving each complaint a full audit trail.
"""

from datetime import datetime
from app.extensions import db


class Update(db.Model):
    __tablename__ = "updates"

    id = db.Column(db.Integer, primary_key=True)
    complaint_id = db.Column(
        db.Integer, db.ForeignKey("complaints.id"), nullable=False, index=True
    )

    updated_by = db.Column(db.String(100), nullable=False)
    remark = db.Column(db.String(500), nullable=True)
    status = db.Column(db.String(20), nullable=False)

    updated_at = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)

    def to_dict(self):
        return {
            "id": self.id,
            "complaint_id": self.complaint_id,
            "updated_by": self.updated_by,
            "remark": self.remark,
            "status": self.status,
            "updated_at": self.updated_at.isoformat() + "Z" if self.updated_at else None,
        }

    def __repr__(self):
        return f"<Update {self.id} | complaint={self.complaint_id} | {self.status}>"
