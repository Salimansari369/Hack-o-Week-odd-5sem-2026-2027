"""
Dashboard statistics endpoint.

    GET /api/stats
"""

from flask import Blueprint
from app.services import stats_service
from app.utils.responses import success_response

stats_bp = Blueprint("stats", __name__, url_prefix="/api")


@stats_bp.route("/stats", methods=["GET"])
def get_stats():
    stats = stats_service.get_dashboard_stats()
    return success_response(data=stats, message="Dashboard statistics fetched successfully.")
