"""
REST endpoints for complaint resources.

    GET    /api/complaints              list + filter + search + paginate
    POST   /api/complaints              create a new complaint
    GET    /api/complaints/<id>         retrieve a single complaint
    PATCH  /api/complaints/<id>         edit complaint details (admin)
    DELETE /api/complaints/<id>         delete a complaint (admin)
    GET    /api/complaints/<id>/updates fetch the audit trail for a complaint
"""

from flask import Blueprint, request

from app.services import complaint_service, update_service
from app.utils.decorators import admin_required
from app.utils.errors import ValidationError
from app.utils.responses import success_response
from app.utils.validators import validate_complaint_payload

complaints_bp = Blueprint("complaints", __name__, url_prefix="/api/complaints")


@complaints_bp.route("", methods=["GET"])
def list_complaints():
    items, meta = complaint_service.list_complaints(request.args)
    return success_response(
        data=[c.to_dict() for c in items],
        message=f"Fetched {len(items)} complaint(s).",
        meta=meta,
    )


@complaints_bp.route("", methods=["POST"])
def create_complaint():
    data = request.get_json(silent=True) or {}

    errors = validate_complaint_payload(data, partial=False)
    if errors:
        raise ValidationError("Complaint could not be created due to validation errors.", errors=errors)

    complaint = complaint_service.create_complaint(data)
    return success_response(
        data=complaint.to_dict(),
        message="Complaint reported successfully. Save the complaint ID to track its progress.",
        status_code=201,
    )


@complaints_bp.route("/<int:complaint_id>", methods=["GET"])
def get_complaint(complaint_id):
    complaint = complaint_service.get_complaint_or_404(complaint_id)
    return success_response(
        data=complaint.to_dict(include_updates=True),
        message="Complaint fetched successfully.",
    )


@complaints_bp.route("/<int:complaint_id>", methods=["PATCH"])
@admin_required
def patch_complaint(complaint_id):
    data = request.get_json(silent=True) or {}

    errors = validate_complaint_payload(data, partial=True)
    if errors:
        raise ValidationError("Complaint could not be updated due to validation errors.", errors=errors)

    complaint = complaint_service.update_complaint(complaint_id, data)
    return success_response(
        data=complaint.to_dict(),
        message="Complaint updated successfully.",
    )


@complaints_bp.route("/<int:complaint_id>", methods=["DELETE"])
@admin_required
def delete_complaint(complaint_id):
    complaint_service.delete_complaint(complaint_id)
    return success_response(
        data={"id": complaint_id},
        message="Complaint deleted successfully.",
    )


@complaints_bp.route("/<int:complaint_id>/updates", methods=["GET"])
def get_complaint_updates(complaint_id):
    updates = update_service.get_updates_for_complaint(complaint_id)
    return success_response(
        data=[u.to_dict() for u in updates],
        message=f"Fetched {len(updates)} update(s) for complaint {complaint_id}.",
    )
