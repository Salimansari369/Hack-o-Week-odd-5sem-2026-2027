"""
REST endpoint for recording status updates on a complaint.

    POST /api/updates

Body:
    {
        "complaint_id": 12,
        "status": "In Progress",
        "updated_by": "Admin - Electrical Dept",
        "remark": "Technician assigned, visiting tomorrow."
    }

This is intentionally separate from PATCH /api/complaints/<id> so that
every status transition is captured as an immutable audit-trail entry
and validated against the allowed state machine.
"""

from flask import Blueprint, request

from app.services import update_service
from app.utils.decorators import admin_required
from app.utils.errors import ValidationError
from app.utils.responses import success_response
from app.utils.validators import validate_update_payload

updates_bp = Blueprint("updates", __name__, url_prefix="/api/updates")


@updates_bp.route("", methods=["POST"])
@admin_required
def create_update():
    data = request.get_json(silent=True) or {}

    errors = validate_update_payload(data)
    if errors:
        raise ValidationError("Update could not be recorded due to validation errors.", errors=errors)

    update, complaint = update_service.add_status_update(data)
    return success_response(
        data={
            "update": update.to_dict(),
            "complaint": complaint.to_dict(),
        },
        message=f"Complaint #{complaint.id} marked as '{complaint.status}'.",
        status_code=201,
    )
