"""
Lightweight admin-authentication helper endpoint.

CampusCare uses a shared-secret admin key (see ADMIN_KEY in config)
rather than full user accounts, in line with the project's scope.
This endpoint lets the frontend verify a key before storing it,
instead of silently failing on the first protected action.
"""

from flask import Blueprint, request, current_app

from app.utils.responses import success_response, error_response

auth_bp = Blueprint("auth", __name__, url_prefix="/api/admin")


@auth_bp.route("/verify", methods=["POST"])
def verify_admin_key():
    data = request.get_json(silent=True) or {}
    supplied_key = str(data.get("admin_key", "")).strip()
    expected_key = current_app.config.get("ADMIN_KEY")

    if supplied_key and supplied_key == expected_key:
        return success_response(data={"valid": True}, message="Admin key verified successfully.")

    return error_response(message="Invalid admin key.", status_code=401)
