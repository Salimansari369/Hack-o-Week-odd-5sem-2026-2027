"""
Metadata endpoints -- exposes dropdown/reference data (categories,
buildings, priorities, statuses) so the frontend never has to
hard-code business rules that live on the backend.
"""

from flask import Blueprint
from app.utils.constants import CATEGORIES, BUILDINGS, PRIORITIES, STATUSES, STATUS_TRANSITIONS
from app.utils.responses import success_response

meta_bp = Blueprint("meta", __name__, url_prefix="/api")


@meta_bp.route("/meta", methods=["GET"])
def get_meta():
    return success_response(
        data={
            "categories": CATEGORIES,
            "buildings": BUILDINGS,
            "priorities": PRIORITIES,
            "statuses": STATUSES,
            "status_transitions": STATUS_TRANSITIONS,
            "app_name": "CampusCare",
        },
        message="Reference data fetched successfully.",
    )
