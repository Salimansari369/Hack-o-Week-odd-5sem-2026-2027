"""
Frontend page routes.

These routes exist purely to serve the HTML shell for each page. All
data is fetched client-side from the REST API in app/static/js -- the
templates themselves contain no server-rendered business data. This
keeps the boundary between backend and frontend clean: the backend
remains a fully functional, independently usable REST API even if
this module (and the entire templates/static folders) is deleted.
"""

from flask import Blueprint, render_template

main_bp = Blueprint("main", __name__)


@main_bp.route("/")
def index():
    return render_template("index.html")


@main_bp.route("/report")
def report():
    return render_template("report.html")


@main_bp.route("/track")
def track():
    return render_template("track.html")


@main_bp.route("/browse")
def browse():
    return render_template("browse.html")


@main_bp.route("/complaint/<int:complaint_id>")
def complaint_detail(complaint_id):
    return render_template("complaint_detail.html", complaint_id=complaint_id)


@main_bp.route("/admin/login")
def admin_login():
    return render_template("admin_login.html")


@main_bp.route("/admin/dashboard")
def admin_dashboard():
    return render_template("admin_dashboard.html")
