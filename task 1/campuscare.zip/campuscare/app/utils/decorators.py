"""
Reusable route decorators.
"""

from functools import wraps
from flask import request, current_app
from app.utils.errors import UnauthorizedError


def admin_required(view_func):
    """
    Protects a route so it can only be accessed with a valid admin key.

    The key must be supplied via the 'X-Admin-Key' request header and
    must match the ADMIN_KEY configured for the application.
    """

    @wraps(view_func)
    def wrapper(*args, **kwargs):
        supplied_key = request.headers.get("X-Admin-Key", "")
        expected_key = current_app.config.get("ADMIN_KEY")

        if not supplied_key or supplied_key != expected_key:
            raise UnauthorizedError(
                "A valid admin key is required for this action. "
                "Supply it via the 'X-Admin-Key' header."
            )
        return view_func(*args, **kwargs)

    return wrapper
