"""
Application-wide constants.

Keeping these centralized means validation rules, dropdown data in the
frontend (via /api/meta), and business logic all stay in sync.
"""

CATEGORIES = [
    "Electrical",
    "Plumbing",
    "Furniture",
    "Internet",
    "Hostel",
    "Classroom",
    "Washroom",
    "Cleaning",
    "Security",
    "Others",
]

BUILDINGS = [
    "Academic Block A",
    "Academic Block B",
    "Academic Block C",
    "Central Library",
    "Hostel Block 1",
    "Hostel Block 2",
    "Hostel Block 3",
    "Cafeteria",
    "Sports Complex",
    "Administration Block",
    "Auditorium",
    "Others",
]

PRIORITIES = ["Low", "Medium", "High"]

STATUSES = ["Pending", "In Progress", "Resolved", "Rejected"]

# Valid forward status transitions. A status can only move to one of the
# statuses listed as its value. Empty list = terminal state.
STATUS_TRANSITIONS = {
    "Pending": ["In Progress", "Rejected"],
    "In Progress": ["Resolved", "Rejected"],
    "Resolved": [],
    "Rejected": [],
}

TERMINAL_STATUSES = ["Resolved", "Rejected"]
