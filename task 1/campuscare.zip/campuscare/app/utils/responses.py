"""
Helpers for producing consistent, well-shaped JSON responses.
"""

from flask import jsonify


def success_response(data=None, message="Success", status_code=200, meta=None):
    """
    Build a standard success envelope.

    {
        "success": true,
        "message": "...",
        "data": ...,
        "meta": {...}   # optional, e.g. pagination info
    }
    """
    body = {"success": True, "message": message}
    if data is not None:
        body["data"] = data
    if meta is not None:
        body["meta"] = meta
    return jsonify(body), status_code


def error_response(message="An error occurred", status_code=400, errors=None):
    body = {"success": False, "message": message}
    if errors:
        body["errors"] = errors
    return jsonify(body), status_code
