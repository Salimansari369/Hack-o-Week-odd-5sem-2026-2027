"""
Input validation for complaint and update payloads.

Every validator returns a list of human-readable error strings. An
empty list means the input is valid. This keeps validation logic
testable and independent of Flask's request context.
"""

import re
from app.utils.constants import CATEGORIES, BUILDINGS, PRIORITIES, STATUSES

EMAIL_REGEX = re.compile(r"^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$")
# Accepts 10-digit Indian mobile numbers, optionally prefixed with +91 / 91 / 0
PHONE_REGEX = re.compile(r"^(?:\+91|91|0)?[6-9]\d{9}$")


def is_valid_email(email):
    return bool(email) and bool(EMAIL_REGEX.match(email.strip()))


def is_valid_phone(phone):
    return bool(phone) and bool(PHONE_REGEX.match(phone.strip().replace(" ", "").replace("-", "")))


def validate_complaint_payload(data, partial=False):
    """
    Validate a complaint creation/update payload.

    When `partial` is True (used for PATCH), only fields that are
    actually present in `data` are validated -- required-field checks
    are skipped for missing keys.
    """
    errors = []

    if not isinstance(data, dict):
        return ["Request body must be a valid JSON object."]

    required_fields = [
        "title", "description", "category", "building",
        "room_number", "priority", "reported_by", "email", "phone",
    ]

    for field in required_fields:
        if not partial and not str(data.get(field, "")).strip():
            errors.append(f"'{field}' is required and cannot be empty.")

    # Title
    if "title" in data and data["title"] is not None:
        title = str(data["title"]).strip()
        if partial and title == "":
            errors.append("'title' cannot be empty.")
        elif title and len(title) < 5:
            errors.append("'title' must be at least 5 characters long.")
        elif title and len(title) > 150:
            errors.append("'title' must not exceed 150 characters.")

    # Description
    if "description" in data and data["description"] is not None:
        desc = str(data["description"]).strip()
        if partial and desc == "":
            errors.append("'description' cannot be empty.")
        elif desc and len(desc) < 10:
            errors.append("'description' must be at least 10 characters long.")
        elif desc and len(desc) > 2000:
            errors.append("'description' must not exceed 2000 characters.")

    # Category
    if "category" in data and data["category"] is not None:
        if str(data["category"]).strip() not in CATEGORIES:
            errors.append(
                f"Invalid category. Must be one of: {', '.join(CATEGORIES)}."
            )

    # Building
    if "building" in data and data["building"] is not None:
        if str(data["building"]).strip() not in BUILDINGS:
            errors.append(
                f"Invalid building. Must be one of: {', '.join(BUILDINGS)}."
            )

    # Room number
    if "room_number" in data and data["room_number"] is not None:
        room = str(data["room_number"]).strip()
        if partial and room == "":
            errors.append("'room_number' cannot be empty.")
        elif room and (len(room) > 20 or not re.match(r"^[A-Za-z0-9\-/ ]+$", room)):
            errors.append(
                "Invalid room_number. Use only letters, numbers, hyphens and slashes "
                "(max 20 characters)."
            )

    # Priority
    if "priority" in data and data["priority"] is not None:
        if str(data["priority"]).strip() not in PRIORITIES:
            errors.append(
                f"Invalid priority. Must be one of: {', '.join(PRIORITIES)}."
            )

    # Email
    if "email" in data and data["email"] is not None:
        email = str(data["email"]).strip()
        if partial and email == "":
            errors.append("'email' cannot be empty.")
        elif email and not is_valid_email(email):
            errors.append("Invalid email address format.")

    # Phone
    if "phone" in data and data["phone"] is not None:
        phone = str(data["phone"]).strip()
        if partial and phone == "":
            errors.append("'phone' cannot be empty.")
        elif phone and not is_valid_phone(phone):
            errors.append(
                "Invalid phone number. Provide a valid 10-digit Indian mobile number."
            )

    # Reported by
    if "reported_by" in data and data["reported_by"] is not None:
        name = str(data["reported_by"]).strip()
        if partial and name == "":
            errors.append("'reported_by' cannot be empty.")
        elif name and len(name) > 100:
            errors.append("'reported_by' must not exceed 100 characters.")

    return errors


def validate_update_payload(data):
    errors = []

    if not isinstance(data, dict):
        return ["Request body must be a valid JSON object."]

    if not str(data.get("complaint_id", "")).strip():
        errors.append("'complaint_id' is required.")
    else:
        try:
            int(data["complaint_id"])
        except (ValueError, TypeError):
            errors.append("'complaint_id' must be an integer.")

    if not str(data.get("status", "")).strip():
        errors.append("'status' is required.")
    elif str(data["status"]).strip() not in STATUSES:
        errors.append(f"Invalid status. Must be one of: {', '.join(STATUSES)}.")

    if not str(data.get("updated_by", "")).strip():
        errors.append("'updated_by' is required (name/role of the admin making the update).")

    remark = data.get("remark", "")
    if remark and len(str(remark)) > 500:
        errors.append("'remark' must not exceed 500 characters.")

    return errors
