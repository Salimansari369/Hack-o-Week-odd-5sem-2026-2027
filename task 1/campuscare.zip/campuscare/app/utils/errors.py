"""
Centralized error handling for the CampusCare API.

All errors -- validation failures, business-rule conflicts, not-found
lookups, and unexpected server errors -- are converted into a
consistent JSON envelope. Stack traces are never exposed to clients.
"""

from flask import jsonify, current_app


class APIError(Exception):
    """
    Base exception for all predictable, application-raised errors.

    Usage:
        raise APIError("Complaint not found", status_code=404)
        raise APIError("Invalid category", status_code=400, errors=["category"])
    """

    def __init__(self, message, status_code=400, errors=None, payload=None):
        super().__init__(message)
        self.message = message
        self.status_code = status_code
        self.errors = errors or []
        self.payload = payload or {}

    def to_dict(self):
        body = {
            "success": False,
            "message": self.message,
        }
        if self.errors:
            body["errors"] = self.errors
        if self.payload:
            body.update(self.payload)
        return body


class NotFoundError(APIError):
    def __init__(self, message="Resource not found", payload=None):
        super().__init__(message, status_code=404, payload=payload)


class ValidationError(APIError):
    def __init__(self, message="Validation failed", errors=None):
        super().__init__(message, status_code=400, errors=errors)


class ConflictError(APIError):
    def __init__(self, message="Conflict", payload=None):
        super().__init__(message, status_code=409, payload=payload)


class UnauthorizedError(APIError):
    def __init__(self, message="Unauthorized"):
        super().__init__(message, status_code=401)


def register_error_handlers(app):
    """Attach JSON error handlers to the Flask app instance."""

    @app.errorhandler(APIError)
    def handle_api_error(err):
        response = jsonify(err.to_dict())
        response.status_code = err.status_code
        return response

    @app.errorhandler(404)
    def handle_404(err):
        return jsonify({
            "success": False,
            "message": "The requested endpoint does not exist.",
        }), 404

    @app.errorhandler(405)
    def handle_405(err):
        return jsonify({
            "success": False,
            "message": "This HTTP method is not allowed on this endpoint.",
        }), 405

    @app.errorhandler(500)
    def handle_500(err):
        # Never leak stack traces to the client.
        current_app.logger.exception("Unhandled server error")
        return jsonify({
            "success": False,
            "message": "An unexpected server error occurred. Please try again later.",
        }), 500

    @app.errorhandler(Exception)
    def handle_unexpected(err):
        if isinstance(err, APIError):
            return handle_api_error(err)
        current_app.logger.exception("Unhandled exception")
        return jsonify({
            "success": False,
            "message": "An unexpected server error occurred. Please try again later.",
        }), 500
