"""
Central place to instantiate Flask extensions.

Instantiating extensions here (rather than inside create_app) avoids
circular imports between models, routes, and the application factory.
"""

from flask_sqlalchemy import SQLAlchemy
from flask_cors import CORS

db = SQLAlchemy()
cors = CORS()
